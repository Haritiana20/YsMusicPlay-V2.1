# Ys Music Play V2.2

Studio : Ys Production  
Créateur : Haritiana

## Modifications incluses
- Interface principale traduite en français (les libellés « Tononkira » et « Filaharana » sont conservés comme demandé).
- Les commandes Equalizer et Bass Booster sont déplacées des Outils vers le lecteur audio.
- Version Android mise à jour en 2.2.

## Limites connues
Cette version ne contient pas encore le Vocal Remover / séparation vocale IA, les préréglages EQ de type VLC, les favoris, l'animation CD, les nouveaux gestes vidéo, ni les autres fonctions avancées demandées. Ces éléments sont réservés à une prochaine version après étude et tests.

La compilation Android n'a pas été exécutée dans l'environnement de préparation. Le résultat doit être vérifié dans GitHub Actions avant installation.
